=== Your Plugin Name ===
Contributors: beeptalk
Tags: beeptalk,chatbot,widget,ai,chatgpt,support,customer service,chat
Requires at least: 6.0
Tested up to: 6.1
Stable tag: 1.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
 
Beeptalk official wordpress plugin.
 
== Description ==
 
Support chatbot service powered by ChatGPT natural language processing AI, bring your customer service to the next level and provide automatic human-like support to your clients.
 
== Installation ==
 
1. Install the plugin.
2. Go to the **Plugins** page and activate the plugin.
3. Go to the Beeptalk widget plugin settings.
4. Copy and paste your Beeptalk project ID (from https://dashboard.beeptalk.app) on the "Beeptalk project ID" field.
5. Set the other other fields as you wish (optional)
6. You are done!
 
== Frequently Asked Questions ==
 
= How do I use this plugin? =
 
You only need to fill the plugin settings on "Beeptalk Widget Settings" with the Beeptalk project ID (mandatory) and the other parameters (optional), and you are done, the widget will show up on your webiste.
 
= How to uninstall the plugin? =
 
Simply deactivate and delete the plugin. 

== Screenshots ==

== Changelog ==
= 1.0.0 =
* Plugin released. 